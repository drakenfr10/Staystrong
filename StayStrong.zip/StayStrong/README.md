# Stay Strong - Android Blocker App

Modern, production-ready Android app for blocking porn sites with motivational support.

## Features

✓ Real-time site detection and blocking
✓ Beautiful Material Design UI
✓ System-wide VPN-level blocking
✓ Stats dashboard
✓ Recent blocks history
✓ Motivational messages
✓ All data stored locally (private)
✓ Auto-start on boot

## How to Build APK

### Option 1: Using Expo (Easiest - Recommended)

1. Go to https://expo.dev/eas
2. Create free account
3. Install Expo CLI: `npm install -g eas-cli`
4. In this folder, run: `eas build --platform android`
5. Download APK from Expo dashboard
6. Transfer to phone and install

### Option 2: Using Buildozer

1. Go to https://buildozer.io
2. Upload this folder as ZIP
3. Click "Build"
4. Download APK
5. Transfer to phone and install

### Option 3: Local Build (Advanced)

```bash
# Install dependencies
npm install

# Build APK
npm run android

# Or use Android Studio:
# 1. Open Android Studio
# 2. File → Open → Select this folder
# 3. Build → Build Bundle(s) / APK(s) → Build APK(s)
```

## Installation on Android

1. Transfer APK to your Android phone
2. Open file manager
3. Find the APK file
4. Tap to install
5. Allow installation from unknown sources if prompted
6. Open app and enable protection

## Project Structure

```
StayStrong/
├── src/
│   ├── App.js          (Main app with all screens)
│   ├── detector.js     (Site detection logic)
│   └── database.js     (Local data storage)
├── package.json        (Dependencies)
├── app.json           (Expo config)
├── babel.config.js    (Babel setup)
└── index.js           (Entry point)
```

## Technology Stack

- React Native
- Expo
- React Navigation
- AsyncStorage
- Material Design Icons

## Privacy

✓ All data stored locally on device
✓ No cloud storage
✓ No analytics
✓ No tracking
✓ No internet required after installation

## Support

For issues or questions, check the app's Help section.

---

**Built for recovery. Built for you.**
