import React, { useEffect, useState, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Switch,
  FlatList,
  StatusBar,
  ActivityIndicator,
  Alert,
  RefreshControl,
} from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { useFocusEffect } from '@react-navigation/native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { Database } from './database';
import { Detector } from './detector';

const Tab = createBottomTabNavigator();
const db = new Database();
const detector = new Detector(db);

const MOTIVATIONAL = [
  "You're stronger than this. One day at a time.",
  "Your future self is proud of you.",
  "This moment is temporary. You can do this.",
  "Every reset counts. You're building real strength.",
  "Your brain is healing. Stick with it.",
  "You've come this far. Don't give up now.",
  "Real connection beats digital escape.",
  "This urge will pass. It always does. Breathe.",
  "You're rewiring your brain. It gets easier.",
  "Relapse is not failure. Getting back up is victory.",
  "Progress over perfection. You're making it.",
  "Sit with the discomfort. It builds character.",
  "Every moment you choose right is a win.",
  "You're not broken. You're growing.",
  "Your mind is powerful. Use it wisely.",
];

function DashboardScreen() {
  const [stats, setStats] = useState({ total: 0, today: 0 });
  const [isActive, setIsActive] = useState(true);
  const [loading, setLoading] = useState(true);
  const [uniqueSites, setUniqueSites] = useState(0);
  const [refreshing, setRefreshing] = useState(false);

  useFocusEffect(
    useCallback(() => {
      loadStats();
    }, [])
  );

  const loadStats = async () => {
    try {
      const s = await db.getTodayStats();
      const unique = await db.getUniqueBlocks();
      setStats(s);
      setUniqueSites(unique);
      setLoading(false);
    } catch (e) {
      console.error('Error loading stats:', e);
      setLoading(false);
    }
  };

  const onRefresh = useCallback(() => {
    setRefreshing(true);
    loadStats();
    setTimeout(() => setRefreshing(false), 500);
  }, []);

  const handleClearHistory = () => {
    Alert.alert(
      'Clear History',
      'Are you sure? This cannot be undone.',
      [
        { text: 'Cancel', onPress: () => {}, style: 'cancel' },
        {
          text: 'Clear',
          onPress: async () => {
            await db.clearHistory();
            loadStats();
            Alert.alert('Success', 'History cleared');
          },
          style: 'destructive'
        }
      ]
    );
  };

  const randomMotivation = MOTIVATIONAL[Math.floor(Math.random() * MOTIVATIONAL.length)];

  return (
    <ScrollView 
      style={styles.container}
      refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}
    >
      <StatusBar barStyle="light-content" backgroundColor="#667eea" />
      
      <View style={styles.header}>
        <View style={styles.headerContent}>
          <Text style={styles.headerTitle}>🛡️ Stay Strong</Text>
          <Text style={styles.headerSubtitle}>Your protection is active</Text>
        </View>
        <View style={[styles.statusDot, isActive && styles.statusActive]} />
      </View>

      <View style={styles.toggleSection}>
        <View style={styles.toggleContent}>
          <Text style={styles.toggleLabel}>Protection Active</Text>
          <Text style={styles.toggleSubtext}>System-wide blocking enabled</Text>
        </View>
        <Switch
          value={isActive}
          onValueChange={setIsActive}
          trackColor={{ false: '#e0e0e0', true: '#81c784' }}
          thumbColor={isActive ? '#4caf50' : '#f1f1f1'}
          style={styles.toggle}
        />
      </View>

      <View style={styles.statsGrid}>
        <View style={styles.statCard}>
          <Text style={styles.statNumber}>{loading ? '...' : stats.today}</Text>
          <Text style={styles.statLabel}>Blocked Today</Text>
        </View>
        <View style={styles.statCard}>
          <Text style={styles.statNumber}>{loading ? '...' : stats.total}</Text>
          <Text style={styles.statLabel}>Total Blocked</Text>
        </View>
        <View style={styles.statCard}>
          <Text style={styles.statNumber}>{loading ? '...' : uniqueSites}</Text>
          <Text style={styles.statLabel}>Unique Sites</Text>
        </View>
      </View>

      <View style={styles.motivationCard}>
        <Text style={styles.motivationIcon}>💪</Text>
        <Text style={styles.motivationText}>{randomMotivation}</Text>
      </View>

      <View style={styles.buttonGroup}>
        <TouchableOpacity style={[styles.button, styles.buttonDanger]} onPress={handleClearHistory}>
          <Icon name="trash-can" size={20} color="#fff" />
          <Text style={styles.buttonText}>Clear History</Text>
        </TouchableOpacity>
        <TouchableOpacity style={[styles.button, styles.buttonPrimary]}>
          <Icon name="help-circle" size={20} color="#fff" />
          <Text style={styles.buttonText}>Get Help</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.infoCard}>
        <Text style={styles.infoTitle}>How it works</Text>
        <Text style={styles.infoText}>
          Stay Strong intercepts all web traffic and analyzes each site in real-time. Adult content is blocked instantly with a motivational message to keep you focused.
        </Text>
      </View>
    </ScrollView>
  );
}

function BlockedListScreen() {
  const [blockedSites, setBlockedSites] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  useFocusEffect(
    useCallback(() => {
      loadSites();
    }, [])
  );

  const loadSites = async () => {
    try {
      const sites = await db.getBlockedSites(100);
      setBlockedSites(sites);
      setLoading(false);
    } catch (e) {
      console.error('Error loading sites:', e);
      setLoading(false);
    }
  };

  const onRefresh = useCallback(() => {
    setRefreshing(true);
    loadSites();
    setTimeout(() => setRefreshing(false), 500);
  }, []);

  return (
    <View style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor="#667eea" />
      
      <View style={styles.screenHeader}>
        <Text style={styles.screenTitle}>Recent Blocks</Text>
        <Text style={styles.screenSubtitle}>Last 100 intercepted sites</Text>
      </View>

      {loading ? (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#667eea" />
        </View>
      ) : blockedSites.length === 0 ? (
        <View style={styles.emptyContainer}>
          <Text style={styles.emptyIcon}>✓</Text>
          <Text style={styles.emptyText}>No blocks yet!</Text>
          <Text style={styles.emptySubtext}>Stay focused and keep it that way</Text>
        </View>
      ) : (
        <FlatList
          data={blockedSites}
          keyExtractor={(item, index) => index.toString()}
          renderItem={({ item }) => (
            <View style={styles.blockItem}>
              <View style={styles.blockItemContent}>
                <Text style={styles.blockDomain} numberOfLines={1}>{item.domain}</Text>
                <Text style={styles.blockReason} numberOfLines={1}>{item.reason}</Text>
                <Text style={styles.blockTime}>
                  {new Date(item.timestamp).toLocaleTimeString()}
                </Text>
              </View>
              <Icon name="block-helper" size={20} color="#e74c3c" />
            </View>
          )}
          scrollEnabled={true}
          style={styles.listContainer}
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}
        />
      )}
    </View>
  );
}

function SettingsScreen() {
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);
  const [dailyStats, setDailyStats] = useState(true);
  const [autoStart, setAutoStart] = useState(true);

  return (
    <ScrollView style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor="#667eea" />
      
      <View style={styles.screenHeader}>
        <Text style={styles.screenTitle}>⚙️ Settings</Text>
      </View>

      <View style={styles.settingsSection}>
        <View style={styles.settingItem}>
          <View>
            <Text style={styles.settingTitle}>Block Notifications</Text>
            <Text style={styles.settingSubtitle}>Get alerted when sites are blocked</Text>
          </View>
          <Switch value={notificationsEnabled} onValueChange={setNotificationsEnabled} />
        </View>

        <View style={styles.settingItem}>
          <View>
            <Text style={styles.settingTitle}>Daily Stats</Text>
            <Text style={styles.settingSubtitle}>See your daily report at midnight</Text>
          </View>
          <Switch value={dailyStats} onValueChange={setDailyStats} />
        </View>

        <View style={styles.settingItem}>
          <View>
            <Text style={styles.settingTitle}>Auto-start on Boot</Text>
            <Text style={styles.settingSubtitle}>Blocker starts automatically</Text>
          </View>
          <Switch value={autoStart} onValueChange={setAutoStart} />
        </View>
      </View>

      <View style={styles.dangerZone}>
        <Text style={styles.dangerTitle}>Danger Zone</Text>
        
        <TouchableOpacity style={styles.dangerButton} onPress={() => {
          Alert.alert(
            'Clear All History',
            'This will delete all blocked site records. Cannot be undone.',
            [
              { text: 'Cancel', style: 'cancel' },
              {
                text: 'Clear All',
                onPress: async () => {
                  await db.clearHistory();
                  Alert.alert('Success', 'All history cleared');
                },
                style: 'destructive'
              }
            ]
          );
        }}>
          <Icon name="trash-can" size={20} color="#e74c3c" />
          <Text style={styles.dangerButtonText}>Clear All History</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.dangerButton}>
          <Icon name="information" size={20} color="#f39c12" />
          <Text style={styles.dangerButtonText}>About & Help</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.dangerButton}>
          <Icon name="heart" size={20} color="#27ae60" />
          <Text style={styles.dangerButtonText}>Support Recovery</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.footer}>
        <Text style={styles.footerText}>Stay Strong v1.0</Text>
        <Text style={styles.footerSubtext}>🔒 All activity stored locally. Your privacy protected.</Text>
        <Text style={styles.footerSubtext}>Built for recovery. Built for you.</Text>
      </View>
    </ScrollView>
  );
}

export default function App() {
  useEffect(() => {
    db.initialize();
  }, []);

  return (
    <NavigationContainer>
      <Tab.Navigator
        screenOptions={({ route }) => ({
          headerShown: false,
          tabBarIcon: ({ focused, color, size }) => {
            let iconName;
            if (route.name === 'Dashboard') iconName = 'home';
            else if (route.name === 'Blocked') iconName = 'block-helper';
            else if (route.name === 'Settings') iconName = 'cog';
            return <Icon name={iconName} size={size} color={color} />;
          },
          tabBarActiveTintColor: '#667eea',
          tabBarInactiveTintColor: '#bdbdbd',
          tabBarStyle: styles.tabBar,
          tabBarLabelStyle: styles.tabBarLabel,
        })}
      >
        <Tab.Screen 
          name="Dashboard" 
          component={DashboardScreen}
          options={{ tabBarLabel: 'Home' }}
        />
        <Tab.Screen 
          name="Blocked" 
          component={BlockedListScreen}
          options={{ tabBarLabel: 'Blocked' }}
        />
        <Tab.Screen 
          name="Settings" 
          component={SettingsScreen}
          options={{ tabBarLabel: 'Settings' }}
        />
      </Tab.Navigator>
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  header: {
    backgroundColor: '#667eea',
    paddingHorizontal: 20,
    paddingTop: 20,
    paddingBottom: 30,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  headerContent: {
    flex: 1,
  },
  headerTitle: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#fff',
    marginBottom: 5,
  },
  headerSubtitle: {
    fontSize: 14,
    color: 'rgba(255,255,255,0.8)',
  },
  statusDot: {
    width: 12,
    height: 12,
    borderRadius: 6,
    backgroundColor: '#ccc',
  },
  statusActive: {
    backgroundColor: '#4caf50',
  },
  toggleSection: {
    backgroundColor: '#fff',
    marginHorizontal: 15,
    marginTop: 15,
    marginBottom: 10,
    padding: 15,
    borderRadius: 12,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  toggleContent: {
    flex: 1,
  },
  toggleLabel: {
    fontSize: 16,
    fontWeight: '600',
    color: '#2c3e50',
  },
  toggleSubtext: {
    fontSize: 13,
    color: '#7f8c8d',
    marginTop: 4,
  },
  toggle: {
    marginLeft: 10,
  },
  statsGrid: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginHorizontal: 15,
    marginBottom: 15,
    gap: 10,
  },
  statCard: {
    flex: 1,
    backgroundColor: '#fff',
    padding: 20,
    borderRadius: 12,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  statNumber: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#667eea',
    marginBottom: 8,
  },
  statLabel: {
    fontSize: 12,
    color: '#7f8c8d',
    fontWeight: '500',
  },
  motivationCard: {
    backgroundColor: '#f39c12',
    marginHorizontal: 15,
    marginBottom: 20,
    padding: 25,
    borderRadius: 12,
    alignItems: 'center',
  },
  motivationIcon: {
    fontSize: 40,
    marginBottom: 10,
  },
  motivationText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#fff',
    textAlign: 'center',
    lineHeight: 24,
  },
  buttonGroup: {
    flexDirection: 'row',
    gap: 10,
    marginHorizontal: 15,
    marginBottom: 20,
  },
  button: {
    flex: 1,
    paddingVertical: 12,
    borderRadius: 10,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
  },
  buttonPrimary: {
    backgroundColor: '#667eea',
  },
  buttonDanger: {
    backgroundColor: '#e74c3c',
  },
  buttonText: {
    color: '#fff',
    fontWeight: '600',
    fontSize: 13,
  },
  infoCard: {
    backgroundColor: '#e8f5e9',
    marginHorizontal: 15,
    marginBottom: 20,
    padding: 15,
    borderRadius: 10,
    borderLeftWidth: 4,
    borderLeftColor: '#4caf50',
  },
  infoTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: '#2e7d32',
    marginBottom: 8,
  },
  infoText: {
    fontSize: 13,
    color: '#558b2f',
    lineHeight: 20,
  },
  screenHeader: {
    backgroundColor: '#667eea',
    paddingHorizontal: 20,
    paddingVertical: 20,
  },
  screenTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#fff',
  },
  screenSubtitle: {
    fontSize: 13,
    color: 'rgba(255,255,255,0.8)',
    marginTop: 5,
  },
  listContainer: {
    paddingHorizontal: 15,
    paddingVertical: 10,
  },
  blockItem: {
    backgroundColor: '#fff',
    marginBottom: 10,
    padding: 15,
    borderRadius: 10,
    borderLeftWidth: 4,
    borderLeftColor: '#e74c3c',
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  blockItemContent: {
    flex: 1,
  },
  blockDomain: {
    fontSize: 14,
    fontWeight: '600',
    color: '#2c3e50',
  },
  blockReason: {
    fontSize: 12,
    color: '#7f8c8d',
    marginTop: 4,
  },
  blockTime: {
    fontSize: 11,
    color: '#bdbdbd',
    marginTop: 4,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    minHeight: 300,
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 20,
    minHeight: 300,
  },
  emptyIcon: {
    fontSize: 60,
    marginBottom: 20,
  },
  emptyText: {
    fontSize: 18,
    fontWeight: '600',
    color: '#2c3e50',
  },
  emptySubtext: {
    fontSize: 14,
    color: '#7f8c8d',
    marginTop: 10,
    textAlign: 'center',
  },
  settingsSection: {
    marginHorizontal: 15,
    marginTop: 20,
    marginBottom: 20,
  },
  settingItem: {
    backgroundColor: '#fff',
    paddingHorizontal: 15,
    paddingVertical: 15,
    marginBottom: 10,
    borderRadius: 10,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  settingTitle: {
    fontSize: 15,
    fontWeight: '600',
    color: '#2c3e50',
  },
  settingSubtitle: {
    fontSize: 12,
    color: '#7f8c8d',
    marginTop: 4,
  },
  dangerZone: {
    marginHorizontal: 15,
    marginBottom: 20,
  },
  dangerTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: '#e74c3c',
    marginBottom: 10,
  },
  dangerButton: {
    backgroundColor: '#fff',
    paddingHorizontal: 15,
    paddingVertical: 15,
    marginBottom: 10,
    borderRadius: 10,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    borderWidth: 1,
    borderColor: '#e74c3c',
  },
  dangerButtonText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#e74c3c',
  },
  footer: {
    paddingHorizontal: 20,
    paddingVertical: 20,
    backgroundColor: '#2c3e50',
    alignItems: 'center',
  },
  footerText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#fff',
  },
  footerSubtext: {
    fontSize: 12,
    color: 'rgba(255,255,255,0.7)',
    marginTop: 5,
    textAlign: 'center',
  },
  tabBar: {
    backgroundColor: '#fff',
    borderTopColor: '#e0e0e0',
    borderTopWidth: 1,
    paddingBottom: 5,
    height: 60,
  },
  tabBarLabel: {
    fontSize: 11,
    marginBottom: 5,
  },
});
