import AsyncStorage from '@react-native-async-storage/async-storage';

export class Database {
  constructor() {
    this.key = '@staystrong_blocked_sites';
    this.statsKey = '@staystrong_stats';
  }

  async initialize() {
    try {
      const data = await AsyncStorage.getItem(this.key);
      if (!data) {
        await this.reset();
      }
    } catch (e) {
      console.error('DB init error:', e);
      await this.reset();
    }
  }

  async addBlockedSite(site) {
    try {
      const dataStr = await AsyncStorage.getItem(this.key);
      const data = dataStr ? JSON.parse(dataStr) : { sites: [] };
      
      data.sites.unshift(site);
      // Keep only last 500 sites to avoid storage bloat
      data.sites = data.sites.slice(0, 500);
      
      await AsyncStorage.setItem(this.key, JSON.stringify(data));
      
      // Update stats
      const statsStr = await AsyncStorage.getItem(this.statsKey);
      const stats = statsStr ? JSON.parse(statsStr) : { total: 0, today: 0 };
      stats.total++;
      stats.today++;
      stats.lastUpdated = new Date().toISOString();
      
      await AsyncStorage.setItem(this.statsKey, JSON.stringify(stats));
    } catch (e) {
      console.error('Error saving site:', e);
    }
  }

  async getBlockedSites(limit = 20) {
    try {
      const dataStr = await AsyncStorage.getItem(this.key);
      const data = dataStr ? JSON.parse(dataStr) : { sites: [] };
      return data.sites.slice(0, limit);
    } catch (e) {
      console.error('Error fetching sites:', e);
      return [];
    }
  }

  async getStats() {
    try {
      const statsStr = await AsyncStorage.getItem(this.statsKey);
      const stats = statsStr ? JSON.parse(statsStr) : { total: 0, today: 0 };
      return stats;
    } catch (e) {
      console.error('Error fetching stats:', e);
      return { total: 0, today: 0 };
    }
  }

  async clearHistory() {
    try {
      await AsyncStorage.removeItem(this.key);
      await this.reset();
    } catch (e) {
      console.error('Error clearing history:', e);
    }
  }

  async reset() {
    try {
      await AsyncStorage.setItem(this.key, JSON.stringify({ sites: [] }));
      await AsyncStorage.setItem(this.statsKey, JSON.stringify({ total: 0, today: 0 }));
    } catch (e) {
      console.error('Error resetting:', e);
    }
  }

  async getTodayStats() {
    try {
      const statsStr = await AsyncStorage.getItem(this.statsKey);
      const stats = statsStr ? JSON.parse(statsStr) : { total: 0, today: 0 };
      
      // Reset today counter at midnight
      const lastUpdated = stats.lastUpdated ? new Date(stats.lastUpdated) : new Date();
      const now = new Date();
      
      if (lastUpdated.toDateString() !== now.toDateString()) {
        stats.today = 0;
      }
      
      return stats;
    } catch (e) {
      return { total: 0, today: 0 };
    }
  }

  async getUniqueBlocks() {
    try {
      const dataStr = await AsyncStorage.getItem(this.key);
      const data = dataStr ? JSON.parse(dataStr) : { sites: [] };
      const uniqueDomains = new Set(data.sites.map(s => s.domain));
      return uniqueDomains.size;
    } catch (e) {
      return 0;
    }
  }
}
