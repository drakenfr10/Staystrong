const ADULT_KEYWORDS = {
  explicit: ['porn', 'xxx', 'sex', 'adult', 'nude', 'naked', 'explicit', 'sexual'],
  imagery: ['cum', 'cock', 'pussy', 'dick', 'boobs', 'ass', 'orgasm', 'penis', 'vagina'],
  services: ['cam', 'escort', 'stripper', 'massage', 'onlyfans', 'dating', 'hookup', 'live sex'],
  platforms: ['chaturbate', 'stripchat', 'camsoda', 'myfreecams'],
};

const ADULT_DOMAINS = [
  'pornhub', 'xvideos', 'xnxx', 'redtube', 'youporn',
  'cam4', 'chaturbate', 'onlyfans', 'stripchat', 'xxx',
  'adult', 'sex', 'porn', 'tube', 'cam', 'escort',
  'spicy', 'naked', 'nude'
];

const SAFE_DOMAINS = [
  'google', 'youtube', 'facebook', 'twitter', 'instagram',
  'reddit', 'wikipedia', 'github', 'stackoverflow', 'medium',
  'linkedin', 'amazon', 'ebay', 'gmail', 'outlook'
];

export class Detector {
  constructor(db) {
    this.db = db;
    this.blockedCount = 0;
    this.cache = {};
  }

  checkDomain(url) {
    try {
      const urlObj = new URL(url);
      const domain = urlObj.hostname.toLowerCase();
      
      // Check cache first
      if (this.cache[domain]) {
        return this.cache[domain];
      }
      
      // Whitelist check
      for (let safe of SAFE_DOMAINS) {
        if (domain.includes(safe)) {
          this.cache[domain] = { blocked: false };
          return { blocked: false };
        }
      }
      
      // Blacklist check
      for (let adult of ADULT_DOMAINS) {
        if (domain.includes(adult)) {
          const result = { blocked: true, reason: `Domain pattern: ${adult}` };
          this.cache[domain] = result;
          return result;
        }
      }
      
      this.cache[domain] = { blocked: false };
      return { blocked: false };
    } catch (e) {
      return { blocked: false };
    }
  }

  analyzeContent(htmlContent) {
    if (!htmlContent || typeof htmlContent !== 'string') {
      return { blocked: false };
    }
    
    const content = htmlContent.toLowerCase();
    let keywordCount = 0;
    let categories = [];
    
    for (let category in ADULT_KEYWORDS) {
      for (let keyword of ADULT_KEYWORDS[category]) {
        const matches = (content.match(new RegExp(keyword, 'g')) || []).length;
        if (matches > 0) {
          keywordCount += matches;
          if (!categories.includes(category)) {
            categories.push(category);
          }
        }
      }
    }
    
    if (keywordCount >= 8) {
      return { blocked: true, reason: `Content keywords: ${keywordCount}` };
    }
    
    if (categories.length >= 2 && keywordCount >= 4) {
      return { blocked: true, reason: `Multiple adult categories detected` };
    }
    
    return { blocked: false };
  }

  async checkURL(url) {
    try {
      // Domain check (instant)
      const domainCheck = this.checkDomain(url);
      if (domainCheck.blocked) {
        return domainCheck;
      }
      
      // Try to fetch content (with timeout)
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 5000);
      
      try {
        const response = await fetch(url, {
          method: 'GET',
          signal: controller.signal,
          headers: {
            'User-Agent': 'Mozilla/5.0 (Android)'
          }
        });
        
        clearTimeout(timeoutId);
        
        if (!response.ok) {
          return { blocked: false };
        }
        
        const html = await response.text();
        return this.analyzeContent(html);
      } catch (e) {
        clearTimeout(timeoutId);
        return { blocked: false };
      }
    } catch (e) {
      return { blocked: false };
    }
  }

  recordBlock(url, reason) {
    this.blockedCount++;
    try {
      const domain = new URL(url).hostname;
      this.db.addBlockedSite({
        url,
        domain,
        reason,
        timestamp: new Date().toISOString()
      });
    } catch (e) {
      console.error('Error recording block:', e);
    }
  }
}
